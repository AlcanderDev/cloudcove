"""API URLs for project."""
from django.conf.urls import include, url

from rest_framework.routers import DefaultRouter

from . import api_views

router = DefaultRouter()

urlpatterns = [
    url(r'^login/?$', api_views.LoginAPIView.as_view(), name='login'),
    url(r'^logout/?$', api_views.LogoutAPIView.as_view(), name='logout'),
    url(r'^signup/?$', api_views.SignUpAPIView.as_view(), name='signup'),
    url(r'^wifi/', include('wifi.api_urls')),
    url(r'button/', include('buttons.api_urls')),
    url(r'order/', include('orders.api_urls')),
]
urlpatterns += router.urls

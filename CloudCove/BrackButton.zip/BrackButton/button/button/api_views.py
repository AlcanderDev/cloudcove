from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from rest_framework import permissions, views, response, status

from tokens.models import Token
from . import serializers


class LoginAPIView(views.APIView):
    serializer_class = serializers.LoginSerializer
    permission_classes = [
        permissions.AllowAny,
    ]

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if not serializer.is_valid():
            return response.Response(serializer.errors,
                                     status.HTTP_400_BAD_REQUEST)
        user = authenticate(
            username=serializer.data.get('username'),
            password=serializer.data.get('password'),)
        if user is not None:
            if user.is_active:
                token, created = Token.objects.get_or_create(user=user)
                return response.Response(
                    {
                        'authtoken': token.key
                    }, status=status.HTTP_200_OK)
            else:  # pragma: nocover
                # should never happen because `authenticate()` returns None
                # if user is inactive
                return response.Response(
                    {
                        'non_field_errors': ['Account is disabled'],
                    },
                    status=status.HTTP_400_BAD_REQUEST,)
        else:
            return response.Response(
                {
                    'non_field_errors': ['Username or password incorrect'],
                },
                status=status.HTTP_400_BAD_REQUEST,)


class SignUpAPIView(views.APIView):
    serializer_class = serializers.SignUpSerializer
    permission_classes = permission_classes = [
        permissions.AllowAny,
    ]

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if not serializer.is_valid():
            return response.Response(serializer.errors,
                                     status.HTTP_400_BAD_REQUEST)
        username = serializer.data.get('username')
        email = serializer.data.get('email')
        password = serializer.data.get('password')

        user = User.objects.create_user(username, email, password)
        token, created = Token.objects.get_or_create(user=user)
        return response.Response(
            {
                'authtoken': token.key
            }, status=status.HTTP_200_OK)


class LogoutAPIView(views.APIView):
    permission_classes = [
        permissions.AllowAny,
    ]

    def post(self, request, *args, **kwargs):
        Token.objects.filter(user=request.user).delete()
        return response.Response(status.HTTP_200_OK)

from rest_framework.authentication import TokenAuthentication
from tokens.models import Token


class CustomTokenAuthentication(TokenAuthentication):
    model = Token

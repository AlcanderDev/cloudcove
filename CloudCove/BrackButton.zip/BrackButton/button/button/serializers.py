from django.contrib.auth.models import User
import django.contrib.auth.password_validation as validators

from rest_framework import serializers


class LoginSerializer(serializers.Serializer):
    """Serializer for the login API."""
    username = serializers.CharField()
    password = serializers.CharField()

    class Meta:
        fields = ('username', 'password')


class SignUpSerializer(serializers.Serializer):
    """Serializer for the signup API"""
    username = serializers.CharField()
    email = serializers.EmailField()
    password = serializers.CharField()

    class Meta:
        fields = ('username', 'email', 'password')

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError('Username already taken!')
        return value

    def validate_email(self, value):
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError(
                'User with this email already exists!')
        return value

    def validate_password(self, value):
        validators.validate_password(password=value)
        return value

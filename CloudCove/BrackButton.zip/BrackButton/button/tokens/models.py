# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import uuid

from django.db import models


class Token(models.Model):
    key = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey('auth.User')
    button = models.ForeignKey('buttons.Button', null=True, blank=True)

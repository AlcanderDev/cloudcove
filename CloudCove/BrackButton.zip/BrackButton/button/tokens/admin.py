# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from . import models


class TokenAdmin(admin.ModelAdmin):
    list_display = ['key', 'user', 'button']


admin.site.register(models.Token, TokenAdmin)

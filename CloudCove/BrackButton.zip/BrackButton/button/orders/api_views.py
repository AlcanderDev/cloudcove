import json
from rest_framework import permissions, views, response, status
from rest_framework import request as req
from django.db import IntegrityError

from tokens.models import Token
from buttons.models import Button
from . import models


class ButtonIOTOrderView(views.APIView):
    permission_classes = [
        permissions.AllowAny,
    ]

    def initialize_request(self, request, *args, **kwargs):
        """
        Returns the initial request object.
        """
        parser_context = self.get_parser_context(request)

        return req.Request(
            request,
            parsers=self.get_parsers(),
            authenticators=self.get_authenticators(),
            negotiator=self.get_content_negotiator(),
            parser_context=parser_context)

    def put(self, request, *args, **kwargs):
        order_id = kwargs.get('order_id')
        token = request.META.get('HTTP_ACCESSTOKEN')
        data = json.loads(request.body)
        device_id = data.get('deviceID')
        # type_str = data.get('type')
        button_id = data.get('buttonID')
        try:
            token = Token.objects.get(key=token)
        except Token.DoesNotExist:
            return response.Response(status=status.HTTP_403_FORBIDDEN)
        button, created = Button.objects.get_or_create(
            device_id=device_id, device_name=device_id, user=token.user)

        try:
            models.Order.objects.create(
                button=button,
                user=token.user,
                sub_button=button_id,
                order_status="ordered",
                order_id=order_id)
        except IntegrityError:
            return response.Response({}, status=status.HTTP_202_ACCEPTED)

        b_list = getattr(button, 'list{}'.format(button_id), None)
        if b_list:
            for item in b_list.buttonlink_set.all():
                models.OrderItem.objects.create(
                    product=item.linked_product,
                    quantity=item.quantity,
                    purchased_price=item.linked_product.price)

        return response.Response({}, status=status.HTTP_201_CREATED)


class OrdersGetView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        resp = []
        for order in user.order_set.all():
            resp.append({
                'order_id': order.order_id,
                'device_id': order.button.device_id,
                'button_id': order.sub_button,
                'ordered_at': order.created_at
            })
        return response.Response({'details': resp}, status=status.HTTP_200_OK)

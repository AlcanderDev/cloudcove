# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Order(models.Model):
    items = models.ManyToManyField('OrderItem', related_name='order')
    button = models.ForeignKey('buttons.Button', null=True)
    user = models.ForeignKey('auth.User')
    sub_button = models.IntegerField()
    order_status = models.CharField(max_length=32)
    order_id = models.CharField(max_length=512, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class OrderItem(models.Model):
    product = models.ForeignKey('products.Product')
    quantity = models.PositiveSmallIntegerField()
    purchased_price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return '{} x{}({})'.format(self.product.title, self.quantity, self.id)

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from . import models


# Register your models here.
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['id', 'purchased_price', 'order']


class OrderAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'user', 'button', 'order_status', 'created_at', 'updated_at'
    ]


admin.site.register(models.OrderItem, OrderItemAdmin)
admin.site.register(models.Order, OrderAdmin)

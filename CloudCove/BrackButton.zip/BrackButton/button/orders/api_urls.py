from django.conf.urls import url

from rest_framework.routers import DefaultRouter

from . import api_views

router = DefaultRouter()
urlpatterns = [
    url(r'get/?$', api_views.OrdersGetView.as_view(), name='orders_get'),
]

virtualenv --no-site-packages env
source env/bin/activate
pip install -r requirements.txt


### Build Image and Run container
```
docker-compose up -d
```

python manage.py createsuperuser
python manage.py migrate
python manage.py runserver
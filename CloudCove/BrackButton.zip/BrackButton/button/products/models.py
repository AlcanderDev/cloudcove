# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Product(models.Model):
    title = models.CharField(max_length=256)
    slug = models.SlugField(max_length=256)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    is_published = models.BooleanField(default=False)
    description = models.TextField(blank=True)
    channel = models.CharField(max_length=256, blank=True)
    listed_SKU = models.CharField(max_length=256)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # url to product image (externally hosted for now)
    image = models.CharField(blank=True, max_length=256)

    def __unicode__(self):
        return self.title

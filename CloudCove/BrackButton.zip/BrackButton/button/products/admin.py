# -*- coding: utf-8 -*-
from django.contrib import admin

from . import models


class ProductAdmin(admin.ModelAdmin):
    list_display = ['title', 'price', 'channel', 'listed_SKU', 'is_published']
    list_filter = ['is_published', 'channel']
    prepopulated_fields = {'slug': ('title', )}


admin.site.register(models.Product, ProductAdmin)

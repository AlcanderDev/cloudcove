import json
from rest_framework import permissions, views, response, status

from tokens.models import Token
from orders.models import Order, OrderItem
from . import serializers, models


# using firmware as authenticate to link button to user
class ButtonIOTAuthenticateView(views.APIView):
    permission_classes = [
        permissions.AllowAny,
    ]

    def get(self, request, *args, **kwargs):
        resp = response.Response(
            {
                'code': 200,
                'message': 'OK',
                'data': {
                    "message": "Firmware is up-to-date"
                }
            },
            status=status.HTTP_200_OK)

        data = json.loads(request.body)
        device_id = args.get('device_id')
        token = data.get('token')
        try:
            token = Token.objects.get(key=token)
        except Token.DoesNotExist:
            return response.Response(
                {
                    'status': -1
                }, status=status.HTTP_404_NOT_FOUND)
        models.Button.objects.create(
            device_id=device_id, device_name=device_id, user=token.user)

        return resp


class ButtonAPIView(views.APIView):
    serializer_class = serializers.ButtonSerializer
    permission_classes = [
        permissions.IsAuthenticated,
    ]

    def put(self, request, *args, **kwargs):
        device_id = request.data.get('deviceID')
        device_name = request.data.get('deviceName')
        user = request.user
        models.Button.objects.create(
            device_id=device_id, device_name=device_name, user=user)
        return response.Response(status=status.HTTP_200_OK)

    def get(self, request, *args, **kwargs):
        user = request.user

        if not kwargs.get('button_id'):
            resp = []
            for button in user.button_set.all():
                resp.append({
                    'button_id': button.pk,
                    'device_id': button.device_id,
                    'image': button.image
                })
            return response.Response(
                {
                    'details': resp
                }, status=status.HTTP_200_OK)
        try:
            button = models.Button.objects.get(pk=kwargs.get('button_id', 0))
            resp = []
            list1 = []
            list2 = []
            list3 = []
            list4 = []
            for item in button.list1.product_list.all():
                list1.append({'item_id': item.pk, 'image': item.image})
            for item in button.list2.product_list.all():
                list2.append({'item_id': item.pk, 'image': item.image})
            for item in button.list3.product_list.all():
                list3.append({'item_id': item.pk, 'image': item.image})
            for item in button.list4.product_list.all():
                list4.append({'item_id': item.pk, 'image': item.image})
            resp.append(list1)
            resp.append(list2)
            resp.append(list3)
            resp.append(list4)
            return response.Response(
                {
                    'details': resp
                }, status=status.HTTP_200_OK)
        except models.Button.DoesNotExist:
            return response.Response(status=status.HTTP_404_NOT_FOUND)


class ButtonOrderAPIView(views.APIView):
    permission_classes = [
        permissions.IsAuthenticated,
    ]

    def put(self, request, *args, **kwargs):
        device_id = request.data.get('deviceID')
        button_id = request.data.get('buttonID')
        # type_str = request.data.get('type')
        # battery = request.data.get('battery')
        # hw = request.data.get('hw')
        # fw = request.data.get('fw')
        user = request.user
        order_id = request.data.get('orderId')

        try:
            button = models.Button.objects.get(device_id=device_id)
        except models.Button.DoesNotExist:
            return response.Response(status=status.HTTP_404_NOT_FOUND)

        orderitems = []
        for product in getattr(button, 'list{}'.format(button_id + 1),
                               []).product_list.all():
            orderitem = OrderItem.objects.create(
                product=product, quantity=1, purchased_price=product.price)
            orderitems.append(orderitem)

        order = Order.objects.create(
            order_id=order_id,
            sub_button=button_id,
            user=user,
            order_status='ordered',
            button=button)
        for item in orderitems:
            order.items.add(item)
        return response.Response(status=status.HTTP_200_OK)

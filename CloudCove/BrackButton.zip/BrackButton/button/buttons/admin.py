# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from . import models


class ButtonLinkInLine(admin.StackedInline):
    model = models.ButtonLink
    extra = 3


class ButtonList(admin.ModelAdmin):
    list_display = ['button']
    inlines = [ButtonLinkInLine]


class ButtonAdmin(admin.ModelAdmin):
    list_display = ['user', 'device_id']


admin.site.register(models.Button, ButtonAdmin)
admin.site.register(models.ButtonList, ButtonList)

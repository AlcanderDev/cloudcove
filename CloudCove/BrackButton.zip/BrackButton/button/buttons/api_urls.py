from django.conf.urls import url

from rest_framework.routers import DefaultRouter

from orders.api_views import ButtonIOTOrderView
from . import api_views

router = DefaultRouter()
urlpatterns = [
    url(r'firmware123/(?P<device_id>[^/.]+)/(?P<hw>[^/]+)/(?P<fw>[^/]+)?$',
        api_views.ButtonIOTAuthenticateView.as_view(),
        name='button_auth'),
    url(r'iot/(?P<order_id>\d+)',
        ButtonIOTOrderView.as_view(),
        name='button_order'),
    url(r'(?P<button_id>\d+)?$',
        api_views.ButtonAPIView.as_view(),
        name='button'),
]

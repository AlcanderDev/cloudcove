# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Button(models.Model):
    # MAC Address
    device_id = models.CharField(max_length=512, unique=True)
    device_name = models.CharField(max_length=512)
    device_state = models.PositiveIntegerField(default=0)
    firmware_vn = models.PositiveSmallIntegerField(default=0)
    hardware_vn = models.PositiveIntegerField(default=0)
    user = models.ForeignKey('auth.User', blank=True, null=True)
    list1 = models.ForeignKey(
        'ButtonList', related_name='button_1', blank=True, null=True)
    list2 = models.ForeignKey(
        'ButtonList', related_name='button_2', blank=True, null=True)
    list3 = models.ForeignKey(
        'ButtonList', related_name='button_3', blank=True, null=True)
    list4 = models.ForeignKey(
        'ButtonList', related_name='button_4', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # image url hosted externally
    image = models.CharField(blank=True, null=True, max_length=256)

    def __unicode__(self):
        return self.device_id


class ButtonList(models.Model):
    product_list = models.ManyToManyField(
        'products.Product', through='ButtonLink')
    button = models.ForeignKey(Button)


class ButtonLink(models.Model):
    linked_button = models.ForeignKey(ButtonList)
    linked_product = models.ForeignKey('products.Product')
    quantity = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

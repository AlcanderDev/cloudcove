from rest_framework import serializers


class ButtonInfoSerializer(serializers.Serializer):
    device_id = serializers.CharField(max_length=12)
    battery = serializers.IntegerField()
    fw = serializers.IntegerField()
    hw = serializers.IntegerField()
    state = serializers.IntegerField()

    class Meta:
        fields = ('device_id', 'battery', 'fw', 'hw', 'state')


class ButtonSerializer(serializers.Serializer):
    button_id = serializers.CharField(required=False)
    authtoken = serializers.CharField()

    class Meta:
        fields = ('button_id', 'authtoken')

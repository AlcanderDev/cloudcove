from rest_framework import serializers


class WifiSerializer(serializers.Serializer):
    """Serializer for the wifi API."""
    ssid = serializers.CharField()
    password = serializers.CharField()

    class Meta:
        fields = ('ssid', 'password')

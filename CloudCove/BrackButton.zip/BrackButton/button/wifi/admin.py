# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from . import models


class WifiAdmin(admin.ModelAdmin):
    list_display = ['user', 'ssid', 'created_at']


admin.site.register(models.Wifi, WifiAdmin)

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Wifi(models.Model):
    ssid = models.CharField(max_length=256)
    password = models.CharField(max_length=256)
    user = models.ForeignKey('auth.User')
    created_at = models.DateTimeField(auto_now_add=True)

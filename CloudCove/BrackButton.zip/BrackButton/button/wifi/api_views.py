from rest_framework import permissions, views, response, status

from . import serializers, models


class WifiGetAPIView(views.APIView):
    permission_classes = [
        permissions.IsAuthenticated,
    ]

    def get(self, request, *args, **kwargs):
        user = request.user
        if not user.wifi_set.exists():
            return response.Response(status=status.HTTP_401_UNAUTHORIZED)
        wifi = user.wifi_set.order_by('-created_at').first()
        return response.Response(
            {
                'ssid': wifi.ssid,
                'password': wifi.password
            },
            status=status.HTTP_200_OK)


class WifiAddAPIView(views.APIView):
    serializer_class = serializers.WifiSerializer
    permission_classes = [
        permissions.IsAuthenticated,
    ]

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        user = request.user
        if not serializer.is_valid():
            return response.Response(serializer.errors,
                                     status.HTTP_400_BAD_REQUEST)
        ssid = serializer.data.get('ssid')
        password = serializer.data.get('password')
        models.Wifi.objects.create(ssid=ssid, password=password, user=user)
        return response.Response(status.HTTP_200_OK)
